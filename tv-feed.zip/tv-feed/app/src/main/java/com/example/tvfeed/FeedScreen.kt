package com.example.tvfeed

import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

data class Video(val title: String, val url: String)

// Replace these with your own videos (any direct .mp4 / HLS URL works).
private const val BASE = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/"
val videos = listOf(
    Video("For Bigger Blazes", BASE + "ForBiggerBlazes.mp4"),
    Video("For Bigger Escapes", BASE + "ForBiggerEscapes.mp4"),
    Video("For Bigger Fun", BASE + "ForBiggerFun.mp4"),
    Video("For Bigger Joyrides", BASE + "ForBiggerJoyrides.mp4"),
    Video("For Bigger Meltdowns", BASE + "ForBiggerMeltdowns.mp4"),
)

@Composable
fun FeedScreen() {
    val context = LocalContext.current
    var index by remember { mutableIntStateOf(0) }
    val focus = remember { FocusRequester() }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            playWhenReady = true
        }
    }

    LaunchedEffect(index) {
        player.setMediaItem(MediaItem.fromUri(videos[index].url))
        player.prepare()
        player.play()
    }
    LaunchedEffect(Unit) { focus.requestFocus() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .focusable()
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                when (e.key) {
                    Key.DirectionDown -> { index = (index + 1) % videos.size; true }
                    Key.DirectionUp -> { index = (index - 1 + videos.size) % videos.size; true }
                    Key.DirectionCenter, Key.Enter -> {
                        if (player.isPlaying) player.pause() else player.play()
                        true
                    }
                    else -> false
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    isFocusable = false
                }
            }
        )
        Text(
            text = "${index + 1}/${videos.size}  ${videos[index].title}",
            color = Color.White,
            fontSize = 22.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(32.dp)
        )
        Text(
            text = "▲▼ change video   OK pause/play",
            color = Color.LightGray,
            fontSize = 16.sp,
            modifier = Modifier.align(Alignment.BottomEnd).padding(32.dp)
        )
    }
}
