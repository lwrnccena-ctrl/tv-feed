# TV Feed (Google TV)

Vertical video feed for Google TV / Android TV. D-pad Up/Down = change video, OK = pause/play.

## Build
Push to GitHub, open Actions > Build APK > download the `tv-feed-debug-apk` artifact.

## Install on TV
Enable Developer options > USB/Wireless debugging, then:
    adb connect <TV_IP>:5555
    adb install app-debug.apk

## Your own videos
Edit the `videos` list in app/src/main/java/com/example/tvfeed/FeedScreen.kt
